class Prefs{
  static String RID = "rid";
  static String RNAME = "rname";
  static String RMOBILE = "rmobile";
  static String RYEAR = "ryear";

  static String ID = "id";
  static String TOKEN = "token";
  static String LOGIN = "login";
  static String TYPE = "type";
}